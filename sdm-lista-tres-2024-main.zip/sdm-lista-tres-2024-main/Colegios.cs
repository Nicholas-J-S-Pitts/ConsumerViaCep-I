 public class School
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Endereco { get; set; }
        public string? Cep { get; set; }
        public int Alunos { get; set; }
        public int Funcionarios { get; set; }
        public string? Grau { get; set; }
        public double Mensalidade { get; set; }
    }

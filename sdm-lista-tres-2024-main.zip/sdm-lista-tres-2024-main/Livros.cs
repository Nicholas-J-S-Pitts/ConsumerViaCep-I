public class Livros {
     public int id { get; set; }
    public string? nome { get; set; }
    public string? Editora { get; set; }
    public string? Autor { get; set; }
    public string? Idioma { get; set; }

    public double preço { get; set; }
    
     public int quantidade { get; set; }

}
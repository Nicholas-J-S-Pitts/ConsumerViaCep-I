public class Shopping {
    public int id { get; set; }
    public string? nome { get; set; }
    public string? Endereço { get; set; }
    public string? Cep { get; set; }

    public int Lojas{ get; set; }
    
     public int vagas { get; set; }
}
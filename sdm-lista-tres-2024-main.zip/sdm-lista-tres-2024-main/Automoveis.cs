public class Automoveis {
     public int id { get; set; }
    public string? nome { get; set; }
    public string? Marca { get; set; }

    public double preço { get; set; }
    
     public int quantidade { get; set; }

}
public class Ferramenta {
     public int id { get; set; }
    public string? nome { get; set; }

    public double preço { get; set; }
    
     public int quantidade { get; set; }

}